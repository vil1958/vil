# Aliases for Windows CLI (cmd.exe)

The Windows shell (cmd.exe) doesn't support aliases by default. 
But we can make it work with them using the doskey utility. 
Doskey is a part of the Windows so you don't need to install anything else.

## Installation

- Download latest https://github.com/azurre/windows-cmd-aliases/archive/master.zip
- run install.bat

## Removal

- run uninstall.bat